package com.example.thaumhexbridge;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.javafmlmod.FMLJavaModLoadingContext;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.ItemStack;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;

@Mod(ThaumHexBridge.MOD_ID)
public class ThaumHexBridge {
    public static final String MOD_ID = "thaumhexbridge";

    public static final DeferredRegister.Items ITEMS =
            DeferredRegister.createItems(MOD_ID);

    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);

    public static final java.util.function.Supplier<Item> HEX_FOCUS =
            ITEMS.register("hex_focus", () -> new Item(new Item.Properties().stacksTo(1)));

    public static final java.util.function.Supplier<CreativeModeTab> MAIN_TAB =
            TABS.register("main", () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.thaumhexbridge"))
                    .icon(() -> new ItemStack(HEX_FOCUS.get()))
                    .displayItems((parameters, output) -> output.accept(HEX_FOCUS.get()))
                    .build());

    public ThaumHexBridge(IEventBus modEventBus, ModContainer modContainer) {
        ITEMS.register(modEventBus);
        TABS.register(modEventBus);
    }
}
